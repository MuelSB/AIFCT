README
--------------------------

To use latex for your reports:

Option 1: https://www.overleaf.com/ is an online LaTeX editor. I don't mind about which template you use.

Option 2: Install on your personal machine:

Download and Install MiKTex: https://miktex.org/download
Download and Install a LaTeX Editor. I use WinEdt9.1 (found here: http://www.winedt.com/archive.html ), but this has annoying pop-ups. This can be disabled (ask me in a Monday session).

If you use my template, modify only the AdvancedTechTemplate.tex file and the AdvancedTech.bib file. Leave Config.tex alone, as it sets up the editor to display things in the correct format.

References go in the AdvancedTech.bib file, and references in the correct BibTex format can be found on Google Scholar for most things.

Then you are ready to go!

Stackoverflow is your friend when you have problems!